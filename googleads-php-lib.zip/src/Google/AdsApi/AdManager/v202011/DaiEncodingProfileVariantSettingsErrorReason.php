<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DaiEncodingProfileVariantSettingsErrorReason
{
    const CONTAINER_TYPE_REQUIRED = 'CONTAINER_TYPE_REQUIRED';
    const VIDEO_SETTINGS_NOT_ALLOWED = 'VIDEO_SETTINGS_NOT_ALLOWED';
    const AUDIO_SETTINGS_NOT_ALLOWED = 'AUDIO_SETTINGS_NOT_ALLOWED';
    const UNKNOWN = 'UNKNOWN';


}
