<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeliveryRateType
{
    const EVENLY = 'EVENLY';
    const FRONTLOADED = 'FRONTLOADED';
    const AS_FAST_AS_POSSIBLE = 'AS_FAST_AS_POSSIBLE';


}
