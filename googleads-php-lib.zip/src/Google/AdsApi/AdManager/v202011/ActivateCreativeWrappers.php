<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ActivateCreativeWrappers extends \Google\AdsApi\AdManager\v202011\CreativeWrapperAction
{

    
    public function __construct()
    {
    
    }

}
