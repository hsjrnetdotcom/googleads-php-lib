<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DelegationType
{
    const UNKNOWN = 'UNKNOWN';
    const MANAGE_ACCOUNT = 'MANAGE_ACCOUNT';
    const MANAGE_INVENTORY = 'MANAGE_INVENTORY';


}
