<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CustomPacingGoalUnit
{
    const ABSOLUTE = 'ABSOLUTE';
    const MILLI_PERCENT = 'MILLI_PERCENT';
    const UNKNOWN = 'UNKNOWN';


}
