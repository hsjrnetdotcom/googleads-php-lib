<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DestinationUrlType
{
    const UNKNOWN = 'UNKNOWN';
    const CLICK_TO_WEB = 'CLICK_TO_WEB';
    const CLICK_TO_APP = 'CLICK_TO_APP';
    const CLICK_TO_CALL = 'CLICK_TO_CALL';
    const NONE = 'NONE';


}
