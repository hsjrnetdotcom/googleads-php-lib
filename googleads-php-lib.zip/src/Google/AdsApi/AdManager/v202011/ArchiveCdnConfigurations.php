<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ArchiveCdnConfigurations extends \Google\AdsApi\AdManager\v202011\CdnConfigurationAction
{

    
    public function __construct()
    {
    
    }

}
