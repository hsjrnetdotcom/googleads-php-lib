<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AudienceSegmentApprovalStatus
{
    const UNAPPROVED = 'UNAPPROVED';
    const APPROVED = 'APPROVED';
    const REJECTED = 'REJECTED';
    const UNKNOWN = 'UNKNOWN';


}
