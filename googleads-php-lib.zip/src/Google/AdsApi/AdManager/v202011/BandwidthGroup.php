<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class BandwidthGroup extends \Google\AdsApi\AdManager\v202011\Technology
{

    /**
     * @param int $id
     * @param string $name
     */
    public function __construct($id = null, $name = null)
    {
      parent::__construct($id, $name);
    }

}
