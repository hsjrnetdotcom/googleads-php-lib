<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ActivateCmsMetadataKeys extends \Google\AdsApi\AdManager\v202011\CmsMetadataKeyAction
{

    
    public function __construct()
    {
    
    }

}
