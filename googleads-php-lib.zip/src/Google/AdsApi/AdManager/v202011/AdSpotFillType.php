<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdSpotFillType
{
    const REQUIRED = 'REQUIRED';
    const OPTIONAL = 'OPTIONAL';
    const UNKNOWN = 'UNKNOWN';


}
