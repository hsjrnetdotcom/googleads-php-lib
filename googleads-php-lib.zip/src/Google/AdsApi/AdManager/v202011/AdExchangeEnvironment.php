<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdExchangeEnvironment
{
    const DISPLAY = 'DISPLAY';
    const VIDEO = 'VIDEO';
    const GAMES = 'GAMES';
    const MOBILE = 'MOBILE';
    const MOBILE_OUTSTREAM_VIDEO = 'MOBILE_OUTSTREAM_VIDEO';
    const DISPLAY_OUTSTREAM_VIDEO = 'DISPLAY_OUTSTREAM_VIDEO';
    const UNKNOWN = 'UNKNOWN';


}
