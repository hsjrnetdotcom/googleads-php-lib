<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ContentFilterErrorReason
{
    const UNKNOWN = 'UNKNOWN';
    const WRONG_NUMBER_OF_ARGUMENTS = 'WRONG_NUMBER_OF_ARGUMENTS';
    const ANY_FILTER_NOT_SUPPORTED = 'ANY_FILTER_NOT_SUPPORTED';


}
