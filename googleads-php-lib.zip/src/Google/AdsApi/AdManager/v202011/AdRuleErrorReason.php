<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdRuleErrorReason
{
    const NAME_CONTAINS_INVALID_CHARACTERS = 'NAME_CONTAINS_INVALID_CHARACTERS';
    const BREAK_TEMPLATE_MUST_HAVE_EXACTLY_ONE_FLEXIBLE_AD_SPOT = 'BREAK_TEMPLATE_MUST_HAVE_EXACTLY_ONE_FLEXIBLE_AD_SPOT';
    const UNKNOWN = 'UNKNOWN';


}
