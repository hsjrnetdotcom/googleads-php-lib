<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CompanyCreditStatus
{
    const ACTIVE = 'ACTIVE';
    const ON_HOLD = 'ON_HOLD';
    const CREDIT_STOP = 'CREDIT_STOP';
    const INACTIVE = 'INACTIVE';
    const BLOCKED = 'BLOCKED';


}
