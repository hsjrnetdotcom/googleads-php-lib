<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdRuleTargetingErrorReason
{
    const VIDEO_POSITION_TARGETING_NOT_ALLOWED = 'VIDEO_POSITION_TARGETING_NOT_ALLOWED';
    const EXACT_CUSTOM_VALUE_TARGETING_REQUIRED = 'EXACT_CUSTOM_VALUE_TARGETING_REQUIRED';
    const UNKNOWN = 'UNKNOWN';


}
