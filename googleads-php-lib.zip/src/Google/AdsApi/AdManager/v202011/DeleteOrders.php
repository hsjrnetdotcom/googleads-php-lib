<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeleteOrders extends \Google\AdsApi\AdManager\v202011\OrderAction
{

    
    public function __construct()
    {
    
    }

}
