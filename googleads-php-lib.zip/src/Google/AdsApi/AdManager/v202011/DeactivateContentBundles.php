<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeactivateContentBundles extends \Google\AdsApi\AdManager\v202011\ContentBundleAction
{

    
    public function __construct()
    {
    
    }

}
