<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CreativeWrapperOrdering
{
    const NO_PREFERENCE = 'NO_PREFERENCE';
    const INNER = 'INNER';
    const OUTER = 'OUTER';


}
