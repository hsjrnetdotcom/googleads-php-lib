<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DaiEncodingProfileUpdateErrorReason
{
    const CANNOT_UPDATE_IF_USED_BY_RUNNING_LIVE_STREAMS = 'CANNOT_UPDATE_IF_USED_BY_RUNNING_LIVE_STREAMS';
    const UNKNOWN = 'UNKNOWN';


}
