<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CompanionDeliveryOption
{
    const OPTIONAL = 'OPTIONAL';
    const AT_LEAST_ONE = 'AT_LEAST_ONE';
    const ALL = 'ALL';
    const UNKNOWN = 'UNKNOWN';


}
