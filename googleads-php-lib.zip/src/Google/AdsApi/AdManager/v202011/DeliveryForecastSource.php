<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeliveryForecastSource
{
    const HISTORICAL = 'HISTORICAL';
    const FORECASTING = 'FORECASTING';
    const CUSTOM_PACING_CURVE = 'CUSTOM_PACING_CURVE';
    const UNKNOWN = 'UNKNOWN';


}
