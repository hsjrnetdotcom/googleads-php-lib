<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ActivateAudienceSegments extends \Google\AdsApi\AdManager\v202011\AudienceSegmentAction
{

    
    public function __construct()
    {
    
    }

}
