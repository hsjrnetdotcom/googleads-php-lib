<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class BillingSchedule
{
    const PREPAID = 'PREPAID';
    const END_OF_THE_CAMPAIGN = 'END_OF_THE_CAMPAIGN';
    const STRAIGHTLINE = 'STRAIGHTLINE';
    const PRORATED = 'PRORATED';
    const UNKNOWN = 'UNKNOWN';


}
