<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CustomCriteriaComparisonOperator
{
    const IS = 'IS';
    const IS_NOT = 'IS_NOT';


}
