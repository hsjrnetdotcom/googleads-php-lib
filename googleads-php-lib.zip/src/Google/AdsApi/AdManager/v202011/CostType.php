<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CostType
{
    const CPA = 'CPA';
    const CPC = 'CPC';
    const CPD = 'CPD';
    const CPM = 'CPM';
    const VCPM = 'VCPM';
    const UNKNOWN = 'UNKNOWN';


}
