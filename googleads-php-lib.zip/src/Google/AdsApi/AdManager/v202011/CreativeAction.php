<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
abstract class CreativeAction
{

    
    public function __construct()
    {
    
    }

}
