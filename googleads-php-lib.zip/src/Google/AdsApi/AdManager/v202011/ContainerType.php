<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ContainerType
{
    const TS = 'TS';
    const FMP4 = 'FMP4';
    const HLS_AUDIO = 'HLS_AUDIO';
    const UNKNOWN = 'UNKNOWN';


}
