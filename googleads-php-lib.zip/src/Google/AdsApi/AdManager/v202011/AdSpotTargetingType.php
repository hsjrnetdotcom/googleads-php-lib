<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdSpotTargetingType
{
    const NOT_REQUIRED = 'NOT_REQUIRED';
    const EXPLICITLY_TARGETED = 'EXPLICITLY_TARGETED';
    const EXPLICITLY_TARGETED_EXCEPT_HOUSE = 'EXPLICITLY_TARGETED_EXCEPT_HOUSE';
    const UNKNOWN = 'UNKNOWN';


}
