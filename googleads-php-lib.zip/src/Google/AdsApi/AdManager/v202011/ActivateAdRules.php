<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ActivateAdRules extends \Google\AdsApi\AdManager\v202011\AdRuleAction
{

    
    public function __construct()
    {
    
    }

}
