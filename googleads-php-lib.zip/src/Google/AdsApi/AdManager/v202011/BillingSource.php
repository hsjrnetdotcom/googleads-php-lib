<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class BillingSource
{
    const CONTRACTED = 'CONTRACTED';
    const DFP_VOLUME = 'DFP_VOLUME';
    const THIRD_PARTY_VOLUME = 'THIRD_PARTY_VOLUME';
    const UNKNOWN = 'UNKNOWN';


}
