<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DaiEncodingProfileStatus
{
    const ACTIVE = 'ACTIVE';
    const ARCHIVED = 'ARCHIVED';
    const UNKNOWN = 'UNKNOWN';


}
