<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CompetitiveConstraintScope
{
    const POD = 'POD';
    const STREAM = 'STREAM';
    const UNKNOWN = 'UNKNOWN';


}
