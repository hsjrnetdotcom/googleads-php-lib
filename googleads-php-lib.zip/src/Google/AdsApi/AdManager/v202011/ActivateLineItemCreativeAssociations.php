<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ActivateLineItemCreativeAssociations extends \Google\AdsApi\AdManager\v202011\LineItemCreativeAssociationAction
{

    
    public function __construct()
    {
    
    }

}
