<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CreativeAssetMacroErrorReason
{
    const INVALID_MACRO_NAME = 'INVALID_MACRO_NAME';
    const UNKNOWN = 'UNKNOWN';


}
