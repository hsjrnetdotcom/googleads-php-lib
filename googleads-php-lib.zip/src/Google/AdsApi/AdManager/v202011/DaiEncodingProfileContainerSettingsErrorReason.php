<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DaiEncodingProfileContainerSettingsErrorReason
{
    const TS_MUST_HAVE_AUDIO_OR_VIDEO_SETTINGS = 'TS_MUST_HAVE_AUDIO_OR_VIDEO_SETTINGS';
    const FMP4_MUST_HAVE_EITHER_AUDIO_OR_VIDEO_SETTINGS = 'FMP4_MUST_HAVE_EITHER_AUDIO_OR_VIDEO_SETTINGS';
    const HLS_AUDIO_MUST_HAVE_ONLY_AUDIO_SETTINGS = 'HLS_AUDIO_MUST_HAVE_ONLY_AUDIO_SETTINGS';
    const UNKNOWN = 'UNKNOWN';


}
