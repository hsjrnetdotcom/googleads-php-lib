<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DaiEncodingProfileNameErrorReason
{
    const CONTAINS_INVALID_CHARACTERS = 'CONTAINS_INVALID_CHARACTERS';
    const UNKNOWN = 'UNKNOWN';


}
