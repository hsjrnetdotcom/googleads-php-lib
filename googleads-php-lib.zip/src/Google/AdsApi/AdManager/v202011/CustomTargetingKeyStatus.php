<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CustomTargetingKeyStatus
{
    const ACTIVE = 'ACTIVE';
    const INACTIVE = 'INACTIVE';
    const UNKNOWN = 'UNKNOWN';


}
