<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AudienceSegmentType
{
    const FIRST_PARTY = 'FIRST_PARTY';
    const SHARED = 'SHARED';
    const THIRD_PARTY = 'THIRD_PARTY';
    const UNKNOWN = 'UNKNOWN';


}
