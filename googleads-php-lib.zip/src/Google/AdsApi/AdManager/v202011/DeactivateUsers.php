<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeactivateUsers extends \Google\AdsApi\AdManager\v202011\UserAction
{

    
    public function __construct()
    {
    
    }

}
