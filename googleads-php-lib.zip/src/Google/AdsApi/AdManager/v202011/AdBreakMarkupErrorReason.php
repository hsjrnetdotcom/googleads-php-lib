<?php

namespace Google\AdsApi\AdManager\v202011;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdBreakMarkupErrorReason
{
    const INVALID_AD_BREAK_MARKUPS_FOR_STREAMING_FORMAT = 'INVALID_AD_BREAK_MARKUPS_FOR_STREAMING_FORMAT';
    const UNKNOWN = 'UNKNOWN';


}
